<?php $__env->startSection('page_title','Test Page'); ?>
<?php $__env->startSection('script'); ?>
    <script src="js/test/test.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2><?php echo e($title); ?></h2>
    <p><?php echo e($content); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>