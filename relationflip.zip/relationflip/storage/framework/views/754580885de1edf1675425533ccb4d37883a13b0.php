<?php $__env->startSection('page_title','Welcome to Relationflip'); ?>

<?php $__env->startSection('main-content'); ?>
    <!--Main Slider Start-->
    <section class="home-slider">
        <div class="tp-banner-container">
            <div class="tp-banner">
                <ul>

                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000"
                        data-thumb="images/home-slider/Relationships.jpg" data-saveperformance="off"
                        data-title="Relationships">
                        <img src="images/home-slider/Relationships.jpg" alt="" data-bgposition="center center"
                             data-bgfit="cover" data-bgrepeat="no-repeat">

                        <div class="tp-caption lfb tp-resizeme"
                             data-x="center" data-hoffset="15"
                             data-y="center" data-voffset="-80"
                             data-speed="1500"
                             data-start="500"
                             data-easing="easeOutExpo"
                             data-splitin="none"
                             data-splitout="none"
                             data-elementdelay="0.01"
                             data-endelementdelay="0.3"
                             data-endspeed="1200"
                             data-endeasing="Power4.easeIn"
                             style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                            <div class="big-title"><h2 class="slide-bg-theme">Flip for better Relationships</h2></div>
                        </div>

                        <div class="tp-caption lfb tp-resizeme"
                             data-x="center" data-hoffset="15"
                             data-y="center" data-voffset="-10"
                             data-speed="1500"
                             data-start="750"
                             data-easing="easeOutExpo"
                             data-splitin="none"
                             data-splitout="none"
                             data-elementdelay="0.01"
                             data-endelementdelay="0.3"
                             data-endspeed="1200"
                             data-endeasing="Power4.easeIn"
                             style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                            <div class="big-title"><h2 class="slide-bg-theme slide-bg-black slide-psm">
                                    ปรึกษาเพื่อความสัมพันธ์ที่ดีขึ้น ทั้งในเรื่องของศักยภาพการทำงานและชีวิตส่วนตัว</h2>
                            </div>
                        </div>

                        <div class="tp-caption lfb tp-resizeme"
                             data-x="center" data-hoffset="15"
                             data-y="center" data-voffset="65"
                             data-speed="1500"
                             data-start="1000"
                             data-easing="easeOutExpo"
                             data-splitin="none"
                             data-splitout="none"
                             data-elementdelay="0.01"
                             data-endelementdelay="0.3"
                             data-endspeed="1200"
                             data-endeasing="Power4.easeIn"
                             style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                            <div class="link-btn"><a href="#" class="btn-theme btn-round">เริ่มต้นรับบริการ&nbsp;<i
                                            class="fa fa-arrow-circle-right"></i></a></div>
                        </div>


                    </li>

                    <li data-transition="slideup" data-slotamount="1" data-masterspeed="1000"
                        data-thumb="images/home-slider/2.jpg" data-saveperformance="off"
                        data-title="With Awsome Services">
                        <img src="images/home-slider/2.jpg" alt="" data-bgposition="center center" data-bgfit="cover"
                             data-bgrepeat="no-repeat">

                        <div class="tp-caption lfb tp-resizeme"
                             data-x="right" data-hoffset="-15"
                             data-y="center" data-voffset="-80"
                             data-speed="1500"
                             data-start="500"
                             data-easing="easeOutExpo"
                             data-splitin="none"
                             data-splitout="none"
                             data-elementdelay="0.01"
                             data-endelementdelay="0.3"
                             data-endspeed="1200"
                             data-endeasing="Power4.easeIn"
                             style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                            <div class="big-title"><h2 class="slide-bg-theme">Flip for better Feelings</h2></div>
                        </div>

                        <div class="tp-caption lfb tp-resizeme"
                             data-x="right" data-hoffset="-15"
                             data-y="center" data-voffset="-10"
                             data-speed="1500"
                             data-start="1000"
                             data-easing="easeOutExpo"
                             data-splitin="none"
                             data-splitout="none"
                             data-elementdelay="0.01"
                             data-endelementdelay="0.3"
                             data-endspeed="1200"
                             data-endeasing="Power4.easeIn"
                             style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                            <div class="big-title"><h2 class="slide-bg-theme slide-bg-black slide-psm">ปรึกษาเพื่ออารมณ์
                                    ความรู้สึกที่ดีขึ้น ทั้งในเรื่องของศักยภาพการทำงานและชีวิตส่วนตัว</h2></div>
                        </div>

                        <div class="tp-caption lfb tp-resizeme"
                             data-x="right" data-hoffset="-15"
                             data-y="center" data-voffset="65"
                             data-speed="1500"
                             data-start="1500"
                             data-easing="easeOutExpo"
                             data-splitin="none"
                             data-splitout="none"
                             data-elementdelay="0.01"
                             data-endelementdelay="0.3"
                             data-endspeed="1200"
                             data-endeasing="Power4.easeIn"
                             style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                            <div class="link-btn"><a href="#" class="btn-theme btn-round">เริ่มต้นรับบริการ&nbsp;<i
                                            class="fa fa-arrow-circle-right"></i></a></div>
                        </div>


                    </li>

                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000"
                        data-thumb="images/home-slider/3.jpg" data-saveperformance="off" data-title="We are Awsome">
                        <img src="images/home-slider/3.jpg" alt="" data-bgposition="center center" data-bgfit="cover"
                             data-bgrepeat="no-repeat">


                        <div class="tp-caption lfb tp-resizeme"
                             data-x="left" data-hoffset="15"
                             data-y="center" data-voffset="-80"
                             data-speed="1500"
                             data-start="500"
                             data-easing="easeOutExpo"
                             data-splitin="none"
                             data-splitout="none"
                             data-elementdelay="0.01"
                             data-endelementdelay="0.3"
                             data-endspeed="1200"
                             data-endeasing="Power4.easeIn"
                             style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                            <div class="big-title"><h2 class="slide-bg-theme">Flip for better Healthy Lifestyle</h2>
                            </div>
                        </div>

                        <div class="tp-caption lfb tp-resizeme"
                             data-x="left" data-hoffset="15"
                             data-y="center" data-voffset="-10"
                             data-speed="1500"
                             data-start="1000"
                             data-easing="easeOutExpo"
                             data-splitin="none"
                             data-splitout="none"
                             data-elementdelay="0.01"
                             data-endelementdelay="0.3"
                             data-endspeed="1200"
                             data-endeasing="Power4.easeIn"
                             style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                            <div class="big-title"><h2 class="slide-bg-theme slide-bg-black slide-psm">
                                    ปรึกษาเพื่อสุขภาพของคุณที่ดีขึ้น ทั้งในเรื่องของศักยภาพการทำงานและชีวิตส่วนตัว</h2>
                            </div>
                        </div>

                        <div class="tp-caption lfb tp-resizeme"
                             data-x="left" data-hoffset="15"
                             data-y="center" data-voffset="65"
                             data-speed="1500"
                             data-start="1500"
                             data-easing="easeOutExpo"
                             data-splitin="none"
                             data-splitout="none"
                             data-elementdelay="0.01"
                             data-endelementdelay="0.3"
                             data-endspeed="1200"
                             data-endeasing="Power4.easeIn"
                             style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;">
                            <div class="link-btn"><a href="#" class="btn-theme btn-round">เริ่มต้นรับบริการ&nbsp;<i
                                            class="fa fa-arrow-circle-right"></i></a></div>
                        </div>

                    </li>

                </ul>

                <div class="tp-bannertimer"></div>
            </div>
        </div>
    </section>
    <!--Main Slider End-->

    <!--Feature Section Start-->
    <section class="bo_pt ho_pb">
        <div class="container">
            <div class="row">
                <div class="col-md-12 section-title text-center">
                    <h1 class="title">Relationflip : For The Better Version Of Yourself<br><br>
                        <span>“เพื่อคุณคนใหม่ ที่รู้สึกดีขึ้นกว่าเมื่อวาน”</span></h1>
                    <p class="sub-title">
                        เรามีความตั้งใจที่จะพัฒนาคุณภาพชีวิตของมนุษย์ทั้งในแง่ศักยภาพการทำงานและชีวิตส่วนตัว ในรูปแบบ
                        1:1 ผ่านกระบวนการ Relationflip Analytical Counselling(RFAC) ด้วยทีมงาน Analytical Counselor
                        ที่มีประสบการณ์ด้านจิตวิทยาที่หลากหลาย ครอบคลุมทุกมิติของชีวิต
                        ระบบของเราถูกออกแบบมาเพื่อให้ผู้รับบริการสามารถเลือกหัวข้อที่ต้องการปรึกษาได้ด้วยตนเองจากการประเมินเบื้องต้นด้วย
                        RF Index ซึ่งเป็นลิขสิทธิ์เฉพาะของ Relationflip
                        ซึ่งใช้ในการประเมินสุขภาพองค์กรและเรื่องส่วนตัวแบบองค์รวม</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-lg-offset-0 text-center">
                    <h1 class="title">ขั้นตอนการรับบริการ</h1>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <img src="images/service4.png">
                        <h2>แบบประเมิน RF Index</h2>
                        <h3 class="text-muted">เริ่มต้นด้วยการทำแบบประเมิน RF Index ของคุณ เพื่อนำข้อมูลการประเมินผล
                            เข้าสู่ระบบ RF Analytical Counselling</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <img src="images/service3.png">
                        <h2>ตรวจสอบประวัติ</h2>
                        <h3 class="text-muted">คุณสามารถเลือก Analytical Counselor ได้ด้วยตนเอง
                            โดยเลือกจากประวัติการทำงาน หัวข้อในการให้คำปรึกษา และความสามารถเฉพาะทาง</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <img src="images/service1.png">
                        <h2>ตอบสนองทุกรูปแบบ</h2>
                        <h3 class="text-muted">คุณสามารถจองวัน-เวลานัดหมายเพื่อรับการปรึกษาผ่าน Smart Phone หรือ Tablet
                            ง่ายๆเพียงปลายนิ้ว</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box">
                        <img src="images/service2.png">
                        <h2>ปรึกษาได้ทุกเรื่อง</h2>
                        <h3 class="text-muted">ผ่านระบบโทรศัพท์ ไม่ว่าจะเป็นเรื่องการพัฒนาศักยภาพการทำงาน การค้นหาตนเอง
                            ความสัมพันธ์</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Feature Section End-->

    <!--Testimonials Section Start-->
    <section class="theme-overlay overlay-white bg-img img-2 io_pt fo_pb">
        <div class="container">
            <div class="row">
                <div class="col-md-12 section-title text-center">
                        <h1 class="title">ทีมงานของ&nbsp;<span>Relationflip</span></h1>
                        <h5 class="sub-title sub-title-center">ทีมงาน RF Analytical Counselors
                            ที่มีประสบการณ์ด้านจิตวิทยา
                            ครอบคลุมทุกเรื่องราวที่ต้องการปรึกษา เช่น ความรัก ความสัมพันธ์ ความเครียดจากการทำงาน
                            ฯลฯ</h5>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="testimonial-slider">
                        <div class="item">
                            <div class="testimonial-post">
                                <div class="thumb">
                                    <img src="images/photos/testi-1.jpg" alt="">
                                </div>
                                <ul>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                </ul>
                                <p>" เราสามารถทำประโยชน์ให้คนอื่นได้ เพียงแค่การพูดคุยอย่างมีทักษะ ก็ช่วยให้คนรู้สึกสบายใจขึ้นได้ "</p>
                                <h5 class="testimonial-name">ศศิประภา กระจ่างประทีป</h5>
                                <h5 class="sub-title">พัฒนาศักยภาพตนเอง</h5>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-post">
                                <div class="thumb">
                                    <img src="images/photos/testi-2.jpg" alt="">
                                </div>
                                <ul>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                </ul>
                                <p>"เมื่อคนทุกข์มา เราคุยกับเขาแล้วเขารู้สึกสบายใจขึ้น นี่แหละคือรางวัลของการทำงานค่ะ"</p>
                                <h5 class="testimonial-name">ชญานภัส จิตตรัตน์</h5>
                                <h5 class="sub-title">พัฒนาศักยภาพตนเอง</h5>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-post">
                                <div class="thumb">
                                    <img src="images/photos/testi-3.jpg" alt="">
                                </div>
                                <ul>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                </ul>
                                <p>"ชอบความรู้สึกที่เกิดขึ้น เมื่อคนที่มารับบริการจากเรายิ้มได้ คลายทุกข์ลงบ้าง มีกำลังใจขึ้นค่ะ"</p>
                                <h5 class="testimonial-name">ชินธิดา วิจิตรโสภาพันธ์</h5>
                                <h5 class="sub-title">พัฒนาศักยภาพตนเอง</h5>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimonial-post">
                                <div class="thumb">
                                    <img src="images/photos/testi-4.jpg" alt="">
                                </div>
                                <ul>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                </ul>
                                <p>"แนวทางการจัดการกับเรื่องราวที่ติดขัดในชีวิต หรือมีการเปลี่ยนแปลงไปในทางที่ดีเท่านี้เราก็มีความสุขไปด้วยแล้วค่ะ"</p>
                                <h5 class="testimonial-name">พิมสิริ เรืองจิรนันท์</h5>
                                <h5 class="sub-title">พัฒนาศักยภาพตนเอง</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Testimonials Section End-->

    <!--Gallery Section Start-->
    <section id="gallery" class="go_pt do_pb">
        <div class="container">
            <div class="row">
                <div class="col-md-12 section-title text-center">
                    <h1 class="title">Relationflip&nbsp;<span>Gellery</span></h1>
                    <h5 class="sub-title sub-title-center">กิจกรรมต่างๆ การให้คำแนะนำปรึกษา การจัดกิจกรรมให้ความรู้ของ
                        Relationflip</h5>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">

                    <div class="portfolio-area">

                        <div class="isotopeFilter">

                            <a href="#" data-filter="*" class="current">All</a>
                            <a href="#" data-filter=".filter_i1">People</a>
                            <a href="#" data-filter=".filter_i2">Places</a>
                            <a href="#" data-filter=".filter_i3">Food</a>
                            <a href="#" data-filter=".filter_i4">Objects</a>

                        </div>

                        <div class="isotopeContainer isotop-colunm4 isotop-gutter">

                            <div class="isotope-item filter_i2 filter_i4">
                                <div class="isotop-thumb">
                                    <img src="images/gallery/1.jpg" alt="image">
                                    <div class="isotop-overlay">
                                        <div class="isotop-icons">
                                            <a href="#"><i class="fa fa-link"></i></a>
                                            <a class="lightbox-image" href="images/gallery/1.jpg"
                                               title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="isotope-item filter_i1 filter_i3">
                                <div class="isotop-thumb">
                                    <img src="images/gallery/2.jpg" alt="image">
                                    <div class="isotop-overlay">
                                        <div class="isotop-icons">
                                            <a href="#"><i class="fa fa-link"></i></a>
                                            <a class="lightbox-image" href="images/gallery/2.jpg"
                                               title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="isotope-item filter_i2 filter_i4">
                                <div class="isotop-thumb">
                                    <img src="images/gallery/3.jpg" alt="image">
                                    <div class="isotop-overlay">
                                        <div class="isotop-icons">
                                            <a href="#"><i class="fa fa-link"></i></a>
                                            <a class="lightbox-image" href="images/gallery/3.jpg"
                                               title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="isotope-item filter_i1 filter_i2 filter_i4">
                                <div class="isotop-thumb">
                                    <img src="images/gallery/4.jpg" alt="image">
                                    <div class="isotop-overlay">
                                        <div class="isotop-icons">
                                            <a href="#"><i class="fa fa-link"></i></a>
                                            <a class="lightbox-image" href="images/gallery/4.jpg"
                                               title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="isotope-item filter_i1 filter_i4">
                                <div class="isotop-thumb">
                                    <img src="images/gallery/5.jpg" alt="image">
                                    <div class="isotop-overlay">
                                        <div class="isotop-icons">
                                            <a href="#"><i class="fa fa-link"></i></a>
                                            <a class="lightbox-image" href="images/gallery/5.jpg"
                                               title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="isotope-item filter_i1 filter_i2">
                                <div class="isotop-thumb">
                                    <img src="images/gallery/6.jpg" alt="image">
                                    <div class="isotop-overlay">
                                        <div class="isotop-icons">
                                            <a href="#"><i class="fa fa-link"></i></a>
                                            <a class="lightbox-image" href="images/gallery/6.jpg"
                                               title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="isotope-item filter_i1 filter_i3">
                                <div class="isotop-thumb">
                                    <img src="images/gallery/7.jpg" alt="image">
                                    <div class="isotop-overlay">
                                        <div class="isotop-icons">
                                            <a href="#"><i class="fa fa-link"></i></a>
                                            <a class="lightbox-image" href="images/gallery/7.jpg"
                                               title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="isotope-item filter_i2 filter_i4">
                                <div class="isotop-thumb">
                                    <img src="images/gallery/8.jpg" alt="image">
                                    <div class="isotop-overlay">
                                        <div class="isotop-icons">
                                            <a href="#"><i class="fa fa-link"></i></a>
                                            <a class="lightbox-image" href="images/gallery/8.jpg"
                                               title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--Gallery Section End-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>