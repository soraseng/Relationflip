<!DOCTYPE html>
<html lang="en">
<head>

    <!-- Meta Tags -->
    <meta charset="UTF-8">

    <!-- Theme Page Title -->
    <title>CoMedical - Health & Medical HTML Template</title>

    <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">

    <!-- responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--css link-->
    <link href="css/menuzord/menuzord.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/revolution-slider.css" rel="stylesheet">
    <link href="css/reset-style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/color/themecolor.css" rel="stylesheet" id="colorswitcher">

</head>

<body>

<!--wrapper start-->
<div class="wrapper">

    <!-- Preloader -->
    <div class="preloader"></div>

    <!-- Start Main Header -->
    <header class="mega-header">
        <div class="header-top">

            <div class="container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <a class="logo" href="index.html"><img src="images/logo.png" alt="Logo" title="Medical"></a>
                    </div>

                    <div class="col-lg-8 col-md-8 col-sm-12 header-top-widget headerwidget-style2">
                        <div class="header-widget">
                            <div class="iconbox-widget">
                                <div class="icon">
                                    <i class="flaticon-square"></i>
                                </div>
                                <div class="box-contenet">
                                    <h5 class="title"><a href="#">Opening Hours</a></h5>
                                    <p class="sub-title"><a href="#">Mon - Sat 9.00 - 19.00</a></p>
                                </div>
                            </div>
                            <div class="iconbox-widget">
                                <div class="icon">
                                    <i class="flaticon-medical-1"></i>
                                </div>
                                <div class="box-contenet">
                                    <h5 class="title"><a href="#">Sign In / Sign Up</a></h5>
                                    <p class="sub-title"><a href="#">Free trial for first time</a></p>
                                </div>
                            </div>
                            <div class="iconbox-widget">
                                <div class="icon">
                                    <i class="flaticon-telephone-symbol-button"></i>
                                </div>
                                <div class="box-contenet">
                                    <h5 class="title"><a href="#">Call Us Today</a></h5>
                                    <p class="sub-title"><a href="#">(0)123 456 7890</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!--Header Main-->
        <div class="header-main">
            <div class="container">
                <div class="row clearfix">
                    <!--Main Menu-->
                    <div class="mega-menu col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <nav id="menuzord" class="menuzord menuzord-responsive">
                            <ul class="menuzord-menu">
                                <li class="active"><a href="javascript:void(0)">Home</a>
                                    <ul class="dropdown">
                                        <li>
                                            <a href="javascript:void(0)">Home Multipage</a>
                                            <ul class="dropdown">
                                                <li><a href="index.html">Home Style One</a></li>
                                                <li><a href="index-2.html">Home Style Two</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0)">Home Singlepage</a>
                                            <ul class="dropdown">
                                                <li><a href="index-sp1.html">Home Style One</a></li>
                                                <li><a href="index-sp2.html">Home Style Two</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0)">Home Boxed</a>
                                            <ul class="dropdown">
                                                <li><a href="index-bx-mp1.html">Multipage One</a></li>
                                                <li><a href="index-bx-mp2.html">Multipage Two</a></li>
                                                <li><a href="index-bx-sp1.html">Singlepage One</a></li>
                                                <li><a href="index-bx-sp2.html">Singlepage Two</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="about.html">About</a></li>
                                <li><a href="javascript:void(0)">Services</a>
                                    <ul class="dropdown">
                                        <li><a href="services-style1.html">Services Style One</a></li>
                                        <li><a href="services-style2.html">Services Style Two</a></li>
                                        <li><a href="services-style3.html">Services Style Three</a></li>
                                        <li><a href="service-details.html">Service Details</a></li>
                                        <li><a href="service-details.html">Primary Health Care</a></li>
                                        <li><a href="service-details.html">Pregnancy Delivery</a></li>
                                        <li><a href="service-details.html">Surgery & Transplants</a></li>
                                    </ul>
                                </li>
                                <li><a href="javascript:void(0)">Doctors</a>
                                    <ul class="dropdown">
                                        <li><a href="doctors-style1.html">Doctors Style One</a></li>
                                        <li><a href="doctors-style2.html">Doctors Style Two</a></li>
                                        <li><a href="doctor-details.html">Doctor Details</a></li>
                                    </ul>
                                </li>
                                <li><a href="javascript:void(0)">Pages</a>
                                    <ul class="dropdown">
                                        <li><a href="appointment-style1.html">Appointment</a></li>
                                        <li>
                                            <a href="javascript:void(0)">Gallery</a>
                                            <ul class="dropdown">
                                                <li><a href="gallery-4colunm.html">Gallery Grid 4</a></li>
                                                <li><a href="gallery-3colunm.html">Gallery Grid 3</a></li>
                                                <li><a href="gallery-fullwide.html">Gallery Fullwide</a></li>
                                                <li><a href="gallery-masonry.html">Gallery Masonry</a></li>
                                                <li><a href="gallery-masonry-tiles.html">Gallery Masonry Tiles</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="pricing-style1.html">Pricing</a></li>
                                        <li><a href="testimonials-style1.html">Testimonials</a></li>
                                        <li><a href="faq.html">Faq</a></li>
                                        <li><a href="under-construction.html">Under Construction</a></li>
                                        <li><a href="404.html">404 Page</a></li>
                                    </ul>
                                </li>
                                <li><a href="javascript:void(0)">Blog</a>
                                    <ul class="dropdown">
                                        <li><a href="blog-style1.html">Blog Style One</a></li>
                                        <li><a href="blog-style2.html">Blog Style Two</a></li>
                                        <li><a href="blog-style3.html">Blog Style Three</a></li>
                                        <li><a href="blog-details.html">Blog Details</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.html">Contact</a></li>
                            </ul>

                            <div class="appoint-inner">
                                <div class="appoint-btn text-right">
                                    <a href="appointment-style1.html">Appointment Now</a>
                                </div>
                            </div>
                        </nav>
                    </div>
                    <!--Main Menu End-->
                </div>
            </div>
        </div>
    </header>
    <!--End Main Header -->

    <!--Main Content start-->
    <div class="main-content">

        <!--Main Slider Start-->
        <section class="home-slider">
            <div class="tp-banner-container">
                <div class="tp-banner">
                    <ul>

                        <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/home-slider/1.jpg"  data-saveperformance="off"  data-title="We are Awsome">
                            <img src="images/home-slider/1.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat">

                            <div class="tp-caption lfb tp-resizeme"
                                 data-x="center" data-hoffset="15"
                                 data-y="center" data-voffset="-80"
                                 data-speed="1500"
                                 data-start="500"
                                 data-easing="easeOutExpo"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-elementdelay="0.01"
                                 data-endelementdelay="0.3"
                                 data-endspeed="1200"
                                 data-endeasing="Power4.easeIn"
                                 style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="big-title"><h2 class="slide-bg-theme">We provide the best medical services</h2></div></div>

                            <div class="tp-caption lfb tp-resizeme"
                                 data-x="center" data-hoffset="15"
                                 data-y="center" data-voffset="-10"
                                 data-speed="1500"
                                 data-start="750"
                                 data-easing="easeOutExpo"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-elementdelay="0.01"
                                 data-endelementdelay="0.3"
                                 data-endspeed="1200"
                                 data-endeasing="Power4.easeIn"
                                 style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="big-title"><h2 class="slide-bg-theme slide-bg-black slide-psm">Offering the best medical service</h2></div></div>

                            <div class="tp-caption lfb tp-resizeme"
                                 data-x="center" data-hoffset="15"
                                 data-y="center" data-voffset="65"
                                 data-speed="1500"
                                 data-start="1000"
                                 data-easing="easeOutExpo"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-elementdelay="0.01"
                                 data-endelementdelay="0.3"
                                 data-endspeed="1200"
                                 data-endeasing="Power4.easeIn"
                                 style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="link-btn"><a href="#" class="btn-theme btn-round">MAKE AN APPOINTMENT <i class="fa fa-arrow-circle-right"></i></a></div></div>


                        </li>

                        <li data-transition="slideup" data-slotamount="1" data-masterspeed="1000" data-thumb="images/home-slider/2.jpg"  data-saveperformance="off"  data-title="With Awsome Services">
                            <img src="images/home-slider/2.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat">

                            <div class="tp-caption lfb tp-resizeme"
                                 data-x="right" data-hoffset="-15"
                                 data-y="center" data-voffset="-80"
                                 data-speed="1500"
                                 data-start="500"
                                 data-easing="easeOutExpo"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-elementdelay="0.01"
                                 data-endelementdelay="0.3"
                                 data-endspeed="1200"
                                 data-endeasing="Power4.easeIn"
                                 style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="big-title"><h2 class="slide-bg-theme">We provide the best medical services</h2></div></div>

                            <div class="tp-caption lfb tp-resizeme"
                                 data-x="right" data-hoffset="-15"
                                 data-y="center" data-voffset="-10"
                                 data-speed="1500"
                                 data-start="1000"
                                 data-easing="easeOutExpo"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-elementdelay="0.01"
                                 data-endelementdelay="0.3"
                                 data-endspeed="1200"
                                 data-endeasing="Power4.easeIn"
                                 style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="big-title"><h2 class="slide-bg-theme slide-bg-black slide-psm">Offering the best medical service</h2></div></div>

                            <div class="tp-caption lfb tp-resizeme"
                                 data-x="right" data-hoffset="-15"
                                 data-y="center" data-voffset="65"
                                 data-speed="1500"
                                 data-start="1500"
                                 data-easing="easeOutExpo"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-elementdelay="0.01"
                                 data-endelementdelay="0.3"
                                 data-endspeed="1200"
                                 data-endeasing="Power4.easeIn"
                                 style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="link-btn"><a href="#" class="btn-theme btn-round">CHECK OUR SERVICES <i class="fa fa-arrow-circle-right"></i></a></div></div>


                        </li>

                        <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/home-slider/3.jpg"  data-saveperformance="off"  data-title="We are Awsome">
                            <img src="images/home-slider/3.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat">


                            <div class="tp-caption lfb tp-resizeme"
                                 data-x="left" data-hoffset="15"
                                 data-y="center" data-voffset="-80"
                                 data-speed="1500"
                                 data-start="500"
                                 data-easing="easeOutExpo"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-elementdelay="0.01"
                                 data-endelementdelay="0.3"
                                 data-endspeed="1200"
                                 data-endeasing="Power4.easeIn"
                                 style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="big-title"><h2 class="slide-bg-theme">We provide the best medical services</h2></div></div>

                            <div class="tp-caption lfb tp-resizeme"
                                 data-x="left" data-hoffset="15"
                                 data-y="center" data-voffset="-10"
                                 data-speed="1500"
                                 data-start="1000"
                                 data-easing="easeOutExpo"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-elementdelay="0.01"
                                 data-endelementdelay="0.3"
                                 data-endspeed="1200"
                                 data-endeasing="Power4.easeIn"
                                 style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="big-title"><h2 class="slide-bg-theme slide-bg-black slide-psm">Offering the best medical service</h2></div></div>

                            <div class="tp-caption lfb tp-resizeme"
                                 data-x="left" data-hoffset="15"
                                 data-y="center" data-voffset="65"
                                 data-speed="1500"
                                 data-start="1500"
                                 data-easing="easeOutExpo"
                                 data-splitin="none"
                                 data-splitout="none"
                                 data-elementdelay="0.01"
                                 data-endelementdelay="0.3"
                                 data-endspeed="1200"
                                 data-endeasing="Power4.easeIn"
                                 style="z-index: 4; max-width: auto; max-height: auto; white-space: nowrap;"><div class="link-btn"><a href="#" class="btn-theme btn-round">MAKE AN APPOINTMENT <i class="fa fa-arrow-circle-right"></i></a></div></div>

                        </li>

                    </ul>

                    <div class="tp-bannertimer"></div>
                </div>
            </div>
        </section>
        <!--Main Slider End-->

        <!--Welcome Section Start-->
        <section class="welcome-section io_pt ho_pb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="welcome-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="timetable-box">
                                        <h4 class="title line-bottom">Opening <span>Hours</span></h4>
                                        <ul class="timetable-list">
                                            <li>Monday - Friday <span>9.00 - 20.00</span></li>
                                            <li>Satarday <span>9.00 - 20.00</span></li>
                                            <li>Sunday <span>9.00 - 20.00</span></li>
                                        </ul>
                                        <div class="overlay">
                                            <h5 class="text">Call Us <span>(001) 222 33 789</span> For Emergency</h5>
                                            <a href="#" class="btn-theme btn-gray">appointment now</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="row">
                                        <div class="col-sm-6 col-md-6">
                                            <div class="welcome-membar">
                                                <div class="thumb">
                                                    <img src="images/team/w1.jpg" alt="">
                                                    <div class="membar-info">
                                                        <h4 class="membar-name">Dr. Tailor Doe</h4>
                                                        <h5 class="doc-title">Cardiologist / CEO</h5>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 col-md-6">
                                            <div class="welcome-membar">
                                                <div class="thumb">
                                                    <img src="images/team/w2.jpg" alt="">
                                                    <div class="membar-info">
                                                        <h4 class="membar-name">Dr. Tailor Lori</h4>
                                                        <h5 class="doc-title">Cardiologist / CEO</h5>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Feature Section End-->

        <!--Feature Section Start-->
        <section class="oo_pt ho_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 section-title text-center">
                        <h1 class="title">Medical <span>Service</span></h1>
                        <h5 class="sub-title sub-title-center">There are many variations of lorem of Lorem Ipsum available for use a sit amet, consectetur debits adipisicing lacus.</h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-medical-8 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Primary Health Care</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-transport icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Emergency Care</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-medical-4 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Modern Medical Lab</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-medical-3 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Our Departments</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-medical icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Pregnancy Delivery</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-medical-6 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Radiology Imaging</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Feature Section End-->

        <!--Divider Style Start-->
        <section class="theme-overlay overlay-theme bg-img img-2 do_pt do_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1 class="fs-italic title oo_mt ae_mb">We Serve Better Than Any Other!</h1>
                        <h5 class="fs-italic lh-22 oe_mb">The Best Medical Care In Neywark City there are many variations of lorem of Lorem Ipsum available for use a purus quis sem tincidunt egestas vel id</h5>
                    </div>
                    <div class="col-md-4 text-right bo_mt">
                        <a class="btn-theme btn-black btn-round" href="#">see all package</a>
                    </div>
                </div>
            </div>
        </section>
        <!--Divider Style End-->

        <!--Services Section Start-->
        <section class="io_pt fo_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 section-title text-center">
                        <h1 class="title">We are <span>Specialized</span> in</h1>
                        <h5 class="sub-title sub-title-center">There are many variations of lorem of Lorem Ipsum available for use a sit amet, consectetur debits adipisicing lacus.</h5>
                    </div>
                </div>
                <div class="row services-style">
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="service-post">
                            <div class="thumb">
                                <img src="images/service/1.jpg" alt="">
                            </div>
                            <div class="icon-box">
                                <i class="flaticon-medical icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Pregnancy Delivery</h5>
                                <p>There are many variations of lorem of Lorem Ipsum availablelorem</p>
                                <a href="#" class="btn-link">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="service-post">
                            <div class="thumb">
                                <img src="images/service/2.jpg" alt="">
                            </div>
                            <div class="icon-box">
                                <i class="flaticon-medical-8 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Surgery & Transplants</h5>
                                <p>There are many variations of lorem of Lorem Ipsum availablelorem</p>
                                <a href="#" class="btn-link">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="service-post">
                            <div class="thumb">
                                <img src="images/service/3.jpg" alt="">
                            </div>
                            <div class="icon-box">
                                <i class="flaticon-medical-4 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Modern Function Lab</h5>
                                <p>There are many variations of lorem of Lorem Ipsum availablelorem</p>
                                <a href="#" class="btn-link">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="service-post">
                            <div class="thumb">
                                <img src="images/service/4.jpg" alt="">
                            </div>
                            <div class="icon-box">
                                <i class="flaticon-medical-13 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Dental Care Service</h5>
                                <p>There are many variations of lorem of Lorem Ipsum availablelorem</p>
                                <a href="#" class="btn-link">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="service-post">
                            <div class="thumb">
                                <img src="images/service/5.jpg" alt="">
                            </div>
                            <div class="icon-box">
                                <i class="flaticon-medical-19 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Cancer Treatment Ut</h5>
                                <p>There are many variations of lorem of Lorem Ipsum availablelorem</p>
                                <a href="#" class="btn-link">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-4">
                        <div class="service-post">
                            <div class="thumb">
                                <img src="images/service/6.jpg" alt="">
                            </div>
                            <div class="icon-box">
                                <i class="flaticon-medical-6 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Radiology and Imaging</h5>
                                <p>There are many variations of lorem of Lorem Ipsum availablelorem</p>
                                <a href="#" class="btn-link">read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Services Section End-->

        <!--Divider Style Start-->
        <section class="theme-overlay overlay-white bg-img fo_pt fo_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h1 class="color-theme fz-32 ttu ao_mt bo_mb">The Best Medical Service in Neywark City</h1><h2 class="color-gray fz-32 lts-1 oo_mt bo_mb">We Provide the Best Medical Service</h2>
                        <h3 class="color-gray bo_mb lts-1">Call Us: <span class="color-theme fz-0 fw-600">+(012) 345 6789</span> For Emergency</h3>
                    </div>
                </div>
            </div>
        </section>
        <!--Divider Style End-->

        <!--Gallery Section Start-->
        <section id="gallery" class="go_pt do_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 section-title text-center">
                        <h1 class="title">Our <span>Gallery</span></h1>
                        <h5 class="sub-title sub-title-center">There are many variations of lorem of Lorem Ipsum available for use a sit amet, consectetur debits adipisicing lacus.</h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">

                        <div class="portfolio-area">

                            <div class="isotopeFilter">

                                <a href="#" data-filter="*" class="current">All</a>
                                <a href="#" data-filter=".filter_i1">People</a>
                                <a href="#" data-filter=".filter_i2">Places</a>
                                <a href="#" data-filter=".filter_i3">Food</a>
                                <a href="#" data-filter=".filter_i4">Objects</a>

                            </div>

                            <div class="isotopeContainer isotop-colunm4 isotop-gutter">

                                <div class="isotope-item filter_i2 filter_i4">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/1.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/1.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i1 filter_i3">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/2.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/2.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i2 filter_i4">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/3.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/3.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i1 filter_i2 filter_i4">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/4.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/4.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i1 filter_i4">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/5.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/5.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i1 filter_i2">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/6.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/6.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i1 filter_i3">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/7.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/7.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i2 filter_i4">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/8.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/8.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i1 filter_i3 filter_i4">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/9.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/9.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i1 filter_i3 filter_i4">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/10.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/10.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i1 filter_i3 filter_i4">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/11.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/11.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="isotope-item filter_i1 filter_i3 filter_i4">
                                    <div class="isotop-thumb">
                                        <img src="images/gallery/12.jpg" alt="image">
                                        <div class="isotop-overlay">
                                            <div class="isotop-icons">
                                                <a href="#"><i class="fa fa-link"></i></a>
                                                <a class="lightbox-image" href="images/gallery/12.jpg" title="Title Input Here"><i class="fa fa-dot-circle-o"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </section>
        <!--Gallery Section End-->

        <!--Divider Style Start-->
        <section class="theme-overlay overlay-theme bg-img img-2 do_pt do_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <h1 class="fs-italic title oo_mt ae_mb">We Serve Better Than Any Other!</h1>
                        <h5 class="fs-italic lh-22 oe_mb">The Best Medical Care In Neywark City there are many variations of lorem of Lorem Ipsum available for use a purus quis sem tincidunt egestas vel id</h5>
                    </div>
                    <div class="col-md-4 text-right bo_mt">
                        <a class="btn-theme btn-black btn-round" href="#">view full gallery</a>
                    </div>
                </div>
            </div>
        </section>
        <!--Divider Style End-->

        <!--Team section Start-->
        <section class="team-section io_pt eo_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 section-title text-center">
                        <h1 class="title">Meet Our <span>Doctors</span></h1>
                        <h5 class="sub-title sub-title-center">There are many variations of lorem of Lorem Ipsum available for use a sit amet, consectetur debits adipisicing lacus.</h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="team-post">
                            <div class="thumb">
                                <img src="images/team/1.jpg" alt="">
                                <div class="overlay"><a href="#"><i class="fa fa-link icon"></i></a></div>
                            </div>
                            <div class="content">
                                <h4 class="title">Dr. Jessica Tailor</h4>
                                <h5 class="sub-title">Specialize in Cardiology</h5>
                                <p>Lorem ipsum dolor sit amet, consectetur debits adipisicing elit. Facere voluptatibus doloru amit</p>
                                <a href="#" class="profile">appointment now<i class="fa fa-long-arrow-right icon"></i></a>
                                <div class="member-skill">
                                    <ul class="list-inline">
                                        <li><a href="#"><i class="fa fa-facebook icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus icon"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="team-post">
                            <div class="thumb">
                                <img src="images/team/2.jpg" alt="">
                                <div class="overlay"><a href="#"><i class="fa fa-link icon"></i></a></div>
                            </div>
                            <div class="content">
                                <h4 class="title">Dr. Lori Jeffrey</h4>
                                <h5 class="sub-title">Specialize in Cardiology</h5>
                                <p>Lorem ipsum dolor sit amet, consectetur debits adipisicing elit. Facere voluptatibus doloru amit</p>
                                <a href="#" class="profile">appointment now<i class="fa fa-long-arrow-right icon"></i></a>
                                <div class="member-skill">
                                    <ul class="list-inline">
                                        <li><a href="#"><i class="fa fa-facebook icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus icon"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="team-post">
                            <div class="thumb">
                                <img src="images/team/3.jpg" alt="">
                                <div class="overlay"><a href="#"><i class="fa fa-link icon"></i></a></div>
                            </div>
                            <div class="content">
                                <h4 class="title">Dr. Jeffrey Toy</h4>
                                <h5 class="sub-title">Specialize in Cardiology</h5>
                                <p>Lorem ipsum dolor sit amet, consectetur debits adipisicing elit. Facere voluptatibus doloru amit</p>
                                <a href="#" class="profile">appointment now<i class="fa fa-long-arrow-right icon"></i></a>
                                <div class="member-skill">
                                    <ul class="list-inline">
                                        <li><a href="#"><i class="fa fa-facebook icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus icon"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Team section End-->

        <!--Funfact Divider Start-->
        <section class="theme-overlay overlay-theme bg-img img-2 fo_pt fo_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="funfact-post">
                            <i class="flaticon-trophy icon"></i>
                            <h4 class="fact-count timer" data-from="0" data-to="6224" data-speed="1000" data-refresh-interval="50">6224</h4>

                            <h4 class="title">Total Awards</h4>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="funfact-post">
                            <i class="flaticon-users-group icon"></i>
                            <h4 class="fact-count timer" data-from="0" data-to="3424" data-speed="1000" data-refresh-interval="50">3424</h4>
                            <h4 class="title">Total Doctors</h4>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="funfact-post">
                            <i class="flaticon-medical-10 icon"></i>
                            <h4 class="fact-count timer" data-from="0" data-to="2724" data-speed="1000" data-refresh-interval="50">2724</h4>
                            <h4 class="title">Clinic Services</h4>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="funfact-post">
                            <i class="flaticon-favorite icon"></i>
                            <h4 class="fact-count timer" data-from="0" data-to="1024" data-speed="1000" data-refresh-interval="50">1024</h4>
                            <h4 class="title">Happy Patients</h4>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Funfact Divider End-->

        <!--Feature Section Start-->
        <section class="io_pt fo_pb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-12">
                        <div class="inner-title line-bottom do_mb">
                            <h2 class="title">Why Chose <span>Us</span></h2>
                            <h5 class="color-theme oo_mt ae_mb fw-500">The Best Medical Service of Neywark City</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut mollitia, quidem praesentium deserunt similique asperiores veniam numquam ullam quo. Laboriosam provident, itaque ab, in id consectetur ex. Est vitae officiis animi placeat hic.</p>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="feature-box">
                                    <div class="icon-box">
                                        <i class="flaticon-medical-8 icon"></i>
                                    </div>
                                    <div class="content">
                                        <h5 class="title">Primary Health Care</h5>
                                        <p>There are many variations of lorem of Lorem Ipsum available</p>
                                        <a class="btn-link" href="#">read more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="feature-box">
                                    <div class="icon-box">
                                        <i class="flaticon-transport icon"></i>
                                    </div>
                                    <div class="content">
                                        <h5 class="title">Emergency Treatment</h5>
                                        <p>There are many variations of lorem of Lorem Ipsum available</p>
                                        <a class="btn-link" href="#">read more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="feature-box">
                                    <div class="icon-box">
                                        <i class="flaticon-medical-4 icon"></i>
                                    </div>
                                    <div class="content">
                                        <h5 class="title">Modern Medical Lab</h5>
                                        <p>There are many variations of lorem of Lorem Ipsum available</p>
                                        <a class="btn-link" href="#">read more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="feature-box">
                                    <div class="icon-box">
                                        <i class="flaticon-medical-3 icon"></i>
                                    </div>
                                    <div class="content">
                                        <h5 class="title">Hospital Departments</h5>
                                        <p>There are many variations of lorem of Lorem Ipsum available</p>
                                        <a class="btn-link" href="#">read more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="appointment-form">
                            <h4 class="form-title"><i class="fa fa-calendar"></i>Make an appointment</h4>
                            <form>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <input class="form-control" type="text" name="name" placeholder="Name">
                                    </div>
                                    <div class="form-group col-md-12">
                                        <input type="text" name="e-mail" placeholder="E-mail">
                                    </div>
                                    <div class="form-group col-md-12">
                                        <select class="select-input" name="category">
                                            <option value="" selected="selected">Depertment</option>
                                            <option value="Surgery">Surgery &amp; Transplants</option>
                                            <option value="Emergancy">Emergancy / Critical Care</option>
                                            <option value="Gynaecological">Gynaecological Clinic</option>
                                            <option value="Accident">Accident Injuries</option>
                                            <option value="Outpatient">Outpatient Rehabilitation</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <input type="text" placeholder="Appointment Date" name="date" class="date-picker">
                                    </div>
                                    <div class="form-group col-md-12">
                                        <textarea placeholder="Message"></textarea>
                                    </div>
                                </div>
                                <a class="btn btn-block" href="#">Send Your Message</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Feature Section End-->

        <!--Testimonials Section Start-->
        <section class="theme-overlay overlay-white bg-img img-2 io_pt fo_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 section-title text-center">
                        <h1 class="title">Testi<span>Monials</span></h1>
                        <h5 class="sub-title sub-title-center">There are many variations of lorem of Lorem Ipsum available for use a sit amet, consectetur debits adipisicing lacus.</h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="testimonial-slider">
                            <div class="item">
                                <div class="testimonial-post">
                                    <div class="thumb">
                                        <img src="images/photos/testi-1.jpg" alt="">
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    </ul>
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus distinctio nam eum cumque porro, delectus consequuntur"</p>
                                    <h5 class="testimonial-name">Marisa Stiller</h5>
                                    <h5 class="sub-title">Patient Of Chirst</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-post">
                                    <div class="thumb">
                                        <img src="images/photos/testi-2.jpg" alt="">
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    </ul>
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus distinctio nam eum cumque porro, delectus consequuntur"</p>
                                    <h5 class="testimonial-name">Marisa Stiller</h5>
                                    <h5 class="sub-title">Patient Of Chirst</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-post">
                                    <div class="thumb">
                                        <img src="images/photos/testi-3.jpg" alt="">
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    </ul>
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus distinctio nam eum cumque porro, delectus consequuntur"</p>
                                    <h5 class="testimonial-name">Marisa Stiller</h5>
                                    <h5 class="sub-title">Patient Of Chirst</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-post">
                                    <div class="thumb">
                                        <img src="images/photos/testi-1.jpg" alt="">
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    </ul>
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus distinctio nam eum cumque porro, delectus consequuntur"</p>
                                    <h5 class="testimonial-name">Marisa Stiller</h5>
                                    <h5 class="sub-title">Patient Of Chirst</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-post">
                                    <div class="thumb">
                                        <img src="images/photos/testi-2.jpg" alt="">
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    </ul>
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus distinctio nam eum cumque porro, delectus consequuntur"</p>
                                    <h5 class="testimonial-name">Marisa Stiller</h5>
                                    <h5 class="sub-title">Patient Of Chirst</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-post">
                                    <div class="thumb">
                                        <img src="images/photos/testi-3.jpg" alt="">
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    </ul>
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus distinctio nam eum cumque porro, delectus consequuntur"</p>
                                    <h5 class="testimonial-name">Marisa Stiller</h5>
                                    <h5 class="sub-title">Patient Of Chirst</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-post">
                                    <div class="thumb">
                                        <img src="images/photos/testi-1.jpg" alt="">
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    </ul>
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus distinctio nam eum cumque porro, delectus consequuntur"</p>
                                    <h5 class="testimonial-name">Marisa Stiller</h5>
                                    <h5 class="sub-title">Patient Of Chirst</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-post">
                                    <div class="thumb">
                                        <img src="images/photos/testi-2.jpg" alt="">
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    </ul>
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus distinctio nam eum cumque porro, delectus consequuntur"</p>
                                    <h5 class="testimonial-name">Marisa Stiller</h5>
                                    <h5 class="sub-title">Patient Of Chirst</h5>
                                </div>
                            </div>
                            <div class="item">
                                <div class="testimonial-post">
                                    <div class="thumb">
                                        <img src="images/photos/testi-3.jpg" alt="">
                                    </div>
                                    <ul>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                        <li><a href="#"><i class="fa fa-star icon"></i></a></li>
                                    </ul>
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus distinctio nam eum cumque porro, delectus consequuntur"</p>
                                    <h5 class="testimonial-name">Marisa Stiller</h5>
                                    <h5 class="sub-title">Patient Of Chirst</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Testimonials Section End-->

        <!--News Section Start-->
        <section class="blog-section io_pt eo_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 section-title text-center">
                        <h1 class="title">Latest <span>News</span></h1>
                        <h5 class="sub-title sub-title-center">There are many variations of lorem of Lorem Ipsum available for use a sit amet, consectetur debits adipisicing lacus.</h5>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="blog-post">
                            <div class="thumb">
                                <img src="images/blog/1.jpg" alt="">
                                <div class="overlay">
                                    <a href="#"><i class="fa fa-link icon"></i></a>
                                </div>
                                <div class="blog-post-date"><span>28</span> Dec</div>
                            </div>
                            <div class="content">
                                <h5 class="title">Medical services news er</h5>
                                <div class="meta-tag">
                                    <a href="#">Comment (13)</a>
                                    <a href="#">Likes (19)</a>
                                    <a class="blog-post-authore" href="#">By Jone Doe</a>
                                </div>
                                <p>Eius sed deserunt voluptatum omnis nulla culpl quidem magni facilis asperiores ullam nulla suscipit veniam consequuntur. Eius sed</p>
                                <a class="btn-theme btn-xs" href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="blog-post">
                            <div class="thumb">
                                <img src="images/blog/2.jpg" alt="">
                                <div class="overlay">
                                    <a href="#"><i class="fa fa-link icon"></i></a>
                                </div>
                                <div class="blog-post-date"><span>28</span> Dec</div>
                            </div>
                            <div class="content">
                                <h5 class="title">Medical services news er</h5>
                                <div class="meta-tag">
                                    <a href="#">Comment (13)</a>
                                    <a href="#">Likes (19)</a>
                                    <a class="blog-post-authore" href="#">By Jone Doe</a>
                                </div>
                                <p>Eius sed deserunt voluptatum omnis nulla culpl quidem magni facilis asperiores ullam nulla suscipit veniam consequuntur. Eius sed</p>
                                <a class="btn-theme btn-xs" href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="blog-post">
                            <div class="thumb">
                                <img src="images/blog/3.jpg" alt="">
                                <div class="overlay">
                                    <a href="#"><i class="fa fa-link icon"></i></a>
                                </div>
                                <div class="blog-post-date"><span>28</span> Dec</div>
                            </div>
                            <div class="content">
                                <h5 class="title">Medical services news er</h5>
                                <div class="meta-tag">
                                    <a href="#">Comment (13)</a>
                                    <a href="#">Likes (19)</a>
                                    <a class="blog-post-authore" href="#">By Jone Doe</a>
                                </div>
                                <p>Eius sed deserunt voluptatum omnis nulla culpl quidem magni facilis asperiores ullam nulla suscipit veniam consequuntur. Eius sed</p>
                                <a class="btn-theme btn-xs" href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--News Section End-->

        <!--Feature Section Start-->
        <section class="theme-overlay overlay-white bg-img fo_pt fo_pb">
            <div class="container">
                <div class="row features-style4">
                    <div class="col-md-3 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-medical-10 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">24 Hours Service</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-dollar-symbol-inside-circle icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Online payment</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-technology icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Online Help</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="feature-box">
                            <div class="icon-box">
                                <i class="flaticon-medical-16 icon"></i>
                            </div>
                            <div class="content">
                                <h5 class="title">Our Location</h5>
                                <p>There are many variations of lorem of Lorem Ipsum</p>
                                <a class="btn-link" href="#">read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Feature Section End-->

        <!--Client Divider Start-->
        <section class="bgcolor-theme do_pt do_pb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="client-slider owlnav-true owl-nav3">
                            <a href="#"><img src="images/client/1.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/2.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/3.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/4.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/5.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/6.png" alt="client-logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Client Divider End-->

    </div>
    <!--Main Content end-->

    <!-- Footer Start-->
    <footer class="footer-section">
        <div class="container">
            <div class="row go_pt fo_pb">
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="footer-widget">
                        <a href="#" class="footer-logo"><img src="images/logo-white.png" alt=""></a>
                        <p>Eius sed culpa quidem magni facilis diaiores ullam! Cum dicta nulla emit</p>
                        <div class="widget-contact">
                            <p><i class="fa fa-map"></i>121, Melbourne, Australia</p>
                            <p><i class="fa fa-envelope"></i>support@medical.com</p>
                            <p><i class="flaticon-telephone-symbol-button"></i>(+991) 234 567 8901</p>
                        </div>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fa fa-facebook icon"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter icon"></i></a></li>
                            <li><a href="#"><i class="fa fa-pinterest icon"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube-play icon"></i></a></li>
                            <li><a href="#"><i class="fa fa-envelope icon"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="footer-widget">
                        <div class="footer-widget-title">
                            <h4 class="widget-title">Useful Links</h4>
                        </div>
                        <ul class="widget-links">
                            <li><a href="#">Choosing a doctor</a></li>
                            <li><a href="#">Primary medical care</a></li>
                            <li><a href="#">Discuss your doctor</a></li>
                            <li><a href="#">Client User Account</a></li>
                            <li><a href="#">Our Support Forum</a></li>
                            <li><a href="#">Our Help Center</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2 col-sm-6">
                    <div class="footer-widget">
                        <div class="footer-widget-title">
                            <h4 class="widget-title">services</h4>
                        </div>
                        <ul class="widget-links">
                            <li><a href="#">Emergency Care</a></li>
                            <li><a href="#">Operation Theater</a></li>
                            <li><a href="#">Medical Checkup</a></li>
                            <li><a href="#">Ddiagnostic center</a></li>
                            <li><a href="#">Outdoor Checkup</a></li>
                            <li><a href="#">Pharmacy Service</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="footer-widget">
                        <div class="footer-widget-title">
                            <h4 class="widget-title">Latest News</h4>
                        </div>
                        <div class="widget-news">
                            <div class="widget-news-post">
                                <div class="thumb">
                                    <img src="images/blog/s1.jpg" alt="">
                                </div>
                                <div class="content">
                                    <p class="title"><a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit</a></p>
                                    <div class="meta-date">25 Feb 2017</div>
                                </div>
                            </div>
                            <div class="widget-news-post">
                                <div class="thumb">
                                    <img src="images/blog/s2.jpg" alt="">
                                </div>
                                <div class="content">
                                    <p class="title"><a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit</a></p>
                                    <div class="meta-date">25 Feb 2017</div>
                                </div>
                            </div>
                            <div class="widget-news-post">
                                <div class="thumb">
                                    <img src="images/blog/s3.jpg" alt="">
                                </div>
                                <div class="content">
                                    <p class="title"><a href="#">Lorem ipsum dolor sit amet, consectetur adipisicing elit</a></p>
                                    <div class="meta-date">25 Feb 2017</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="copy-right">© Copyright 2017 - <a href="https://themeforest.net/user/icute_theme/portfolio" target="_blank">ICUTE THEME </a>| all right reserved <a href="https://themeforest.net/checkout/25548483/create_account" class="tf-buy-now" target="_blank"> Buy now </a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--Footer end-->

    <!-- Start Menu Switcher -->
    <div class="menu-switcher">
        <a class="switcher-btn" id="switcher-toggle" href="#"><i class="fa fa-cog"></i></a>
        <h5 class="switcher-title">Reset Theme Style</h5>
        <h6 class="title">Chose theme color</h6>
        <ul class="switcher-color">
            <li>
                <a class="scr-color1" onclick="swapStyleSheet('css/color/themecolor.css')"></a>
            </li>
            <li>
                <a class="scr-color2" onclick="swapStyleSheet('css/color/themecolor2.css')"></a>
            </li>
            <li>
                <a class="scr-color3" onclick="swapStyleSheet('css/color/themecolor3.css')"></a>
            </li>
            <li>
                <a class="scr-color4" onclick="swapStyleSheet('css/color/themecolor4.css')"></a>
            </li>
            <li>
                <a class="scr-color5" onclick="swapStyleSheet('css/color/themecolor5.css')"></a>
            </li>
            <li>
                <a class="scr-color6" onclick="swapStyleSheet('css/color/themecolor6.css')"></a>
            </li>
            <li>
                <a class="scr-color7" onclick="swapStyleSheet('css/color/themecolor7.css')"></a>
            </li>
            <li>
                <a class="scr-color8" onclick="swapStyleSheet('css/color/themecolor8.css')"></a>
            </li>
        </ul>
        <h6 class="title">Chose layout wide</h6>
        <ul class="switcher-laout-boxed-wide">
            <li>
                <a class="btn-widelayout" href="#btn-widelayout">Wide</a>
            </li>
            <li>
                <a class="btn-boxedlayout" href="#btn-boxedlayout">Boxed</a>
            </li>
        </ul>
        <h6 class="title">Chose Background Image <span>(Boxed Wide)</span></h6>
        <ul class="switcher-layout-bgimg">
            <li><a class="switcher-bgi-pattern">rs</a></li>
            <li><a><img class="switcher-bgi-pattern" src="images/resource/w01.jpg"></a></li>
            <li><a><img class="switcher-bgi-pattern" src="images/resource/w02.jpg"></a></li>
            <li><a><img class="switcher-bgi-pattern" src="images/resource/w03.jpg"></a></li>
            <li><a><img class="switcher-bgi-pattern" src="images/resource/w04.jpg"></a></li>
            <li><a><img class="switcher-bgi-pattern" src="images/resource/w05.jpg"></a></li>

            <li><a><img class="switcher-bgi-solid" src="images/resource/1.jpg"></a></li>
            <li><a><img class="switcher-bgi-solid" src="images/resource/2.jpg"></a></li>
            <li><a><img class="switcher-bgi-solid" src="images/resource/3.jpg"></a></li>
            <li><a><img class="switcher-bgi-solid" src="images/resource/4.jpg"></a></li>
            <li><a><img class="switcher-bgi-solid" src="images/resource/5.jpg"></a></li>
            <li><a><img class="switcher-bgi-solid" src="images/resource/6.jpg"></a></li>
        </ul>
    </div>

    <!-- Side Menu-->
    <div class="side-toggle-menu">
        <a class="side-menu-btn toggle-menu menu-right"><i class="fa fa-bars"></i></a>
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-right">
            <a class="side-menu-btn-close pull-right"><i class="fa fa-close"></i></a>
            <a class="logo" href="index.html"><img src="images/logo-white.png" alt="Logo" title="CuteGarden"></a>
            <ul class="nav-stacked">
                <li><a href="index.html">Home</a></li>
                <li><a href="services-style1.html">Services</a></li>
                <li class="sidemenu-dropdown">
                    <a>Pages <span class="caret"></span></a>
                    <ul class="sidemenu-dropdown-active">
                        <li><a href="about.html">About</a></li>
                        <li><a href="pricing-style1.html">Pricing</a></li>
                        <li><a href="testimonials-style1.html">Testimonials</a></li>
                        <li><a href="faq.html">Faq</a></li>
                        <li><a href="404.html">404 Page</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>

    <!--Scroll to top-->
    <div class="scroll-to-top"><span class="fa fa-arrow-up"></span></div>

</div>
<!--wrapper end-->

<!--Jquery Script-->
<script src="js/jquery-2.1.4.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/menuzord.js"></script>
<script src="js/jPushMenu.js"></script>
<script src="js/revolution.min.js"></script>
<script src="js/owl.js"></script>
<!-- validate -->
<script src="js/validate.js"></script>
<!-- jQuery ui js -->
<script src="js/jquery-ui-1.11.4/jquery-ui.js"></script>
<!-- appear js -->
<script src="js/jquery.appear.js"></script>
<!-- isotope -->
<script src="js/isotope.pkgd.min.js"></script>
<!-- count to -->
<script src="js/jquery.countTo.js"></script>
<!-- fancybox -->
<script src="js/jquery.fancybox.pack.js"></script>
<!-- easing -->
<script src="js/jquery.easing.min.js"></script>
<script src="js/wow.js"></script>
<script src="js/rev-custom.js"></script>
<script src="js/customcollection.js"></script>
<script src="js/custom.js"></script>

</body>
</html>