<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
<meta charset="utf-8">
<title>Welcome to <?php echo $__env->yieldContent('page_title'); ?></title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>

<body>
    <div class="row">
        <div class="col-lg-12">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</body>
</html>