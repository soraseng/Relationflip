<?php $__env->startSection('page_title','GetData'); ?>
<?php $__env->startSection('script'); ?>
    <script src="js/test/test.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo e($test1); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>