@extends('layout.mainTest')
@section('page_title','Test Page')
@section('script')
    <script src="js/test/test.js"></script>
@stop
@section('content')
    <h2>{{$title}}</h2>
    <p>{{$content}}</p>
@stop