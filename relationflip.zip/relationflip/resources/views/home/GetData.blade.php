@extends('layout.mainTest')
@section('page_title','GetData')
@section('script')
    <script src="js/test/test.js"></script>
@stop
@section('content')
    {{$test1}}
@stop