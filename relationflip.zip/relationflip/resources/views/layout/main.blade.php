<!DOCTYPE html>
<html lang="en">
<head>

    <!-- Meta Tags -->
    <meta charset="UTF-8">

    <!-- Theme Page Title -->
    <title>@yield('page_title')</title>

    <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">

    <!-- responsive meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--css link-->
    <link href="css/menuzord/menuzord.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/revolution-slider.css" rel="stylesheet">
    <link href="css/reset-style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/color/themecolor.css" rel="stylesheet" id="colorswitcher">

</head>

<body>

<!--wrapper start-->
<div class="wrapper">

    <!-- Preloader -->
    <div class="preloader"></div>

    <!-- Start Main Header -->
    <header class="mega-header">
        <div class="header-top">

            <div class="container">
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <a class="logo" href={{url('/')}}><img src="images/logo.png" alt="Logo" title="Medical"></a>
                    </div>

                    <div class="col-lg-8 col-md-8 col-sm-12 header-top-widget headerwidget-style2">
                        <div class="header-widget">
                            <div class="iconbox-widget">
                                <div class="icon">
                                    <i class="flaticon-square"></i>
                                </div>
                                <div class="box-contenet">
                                    <h5 class="title"><a href="#">เวลาทำการ</a></h5>
                                    <p class="sub-title"><a href="#">จันทร์ - ศุกร์ 9.00 - 19.00</a></p>
                                </div>
                            </div>
                            <div class="iconbox-widget">
                                <div class="icon">
                                    <i class="flaticon-telephone-symbol-button"></i>
                                </div>
                                <div class="box-contenet">
                                    <h5 class="title"><a href="#">เบอร์โทรศัพท์</a></h5>
                                    <p class="sub-title"><a href="#">081-833-0148</a></p>
                                </div>
                            </div>
                            <div class="iconbox-widget">
                                <div class="icon">
                                    <i class="flaticon-medical-1"></i>
                                </div>
                                <div class="box-contenet">
                                    <h5 class="title"><a href="#">เข้าสู่ระบบ</a></h5>
                                    <p class="sub-title"><a href="#">Relationflip Member</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!--Header Main-->
        <div class="header-main">
            <div class="container">
                <div class="row clearfix">
                    <!--Main Menu-->
                    <div class="mega-menu col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <nav id="menuzord" class="menuzord menuzord-responsive">
                            <ul class="menuzord-menu">
                                <li class="active"><a href={{url('/')}}>
                                        <div class="icon">
                                            <i class="fa fa-home fa-lg"></i>
                                        </div>
                                    </a>
                                </li>
                                <li><a href="{{url('about')}}">เกี่ยวกับ Relationflip</a></li>
                                <li><a href="javascript:void(0)">คำถามที่พบบ่อย</a>
                                </li>
                                <li><a href="javascript:void(0)">บทความน่ารู้</a>
                                </li>
                                <li><a href="javascript:void(0)">ติดต่อ สอบถาม</a></li>
                            </ul>

                            <div class="appoint-inner">
                                <div class="appoint-btn text-right">
                                    <a href="javascript:void(0)">Appointment Now</a>
                                </div>
                            </div>
                        </nav>
                    </div>
                    <!--Main Menu End-->
                </div>
            </div>
        </div>
    </header>
    <!--End Main Header -->

    <!--Main Content start-->
    <div class="main-content">
    @yield('main-content')
    <!--//-->
        <!--Client Divider Start-->
        <section class="bgcolor-theme ao_pt">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="client-slider owlnav-true owl-nav3">
                            <a href="#"><img src="images/client/1.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/2.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/3.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/4.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/5.png" alt="client-logo"></a>
                            <a href="#"><img src="images/client/6.png" alt="client-logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Client Divider End-->
    </div>
    <!--Main Content end-->

    <!-- Footer Start-->
    <footer class="footer-section">
        <div class="container">
            <div class="row go_pt fo_pb">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="footer-widget">
                        <a href="#" class="footer-logo"><img src="images/logo.png" alt=""></a>
                        <h3 style="color: white">ติดต่อเว็บไซต์</h3>
                        <div class="widget-contact">
                            <p><i class="fa fa-map"></i>88/66 ม.2 ต.บ้านใหม่ อ.ปากเกร็ด จ.นนทบุรี</p>
                            <p><i class="fa fa-envelope"></i>Contactus@Relationflip.com</p>
                            <p><i class="flaticon-telephone-symbol-button"></i>081-8330148</p>
                        </div>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fa fa-facebook icon"></i></a></li>
                            {{--<li><a href="#"><i class="fa fa-twitter icon"></i></a></li>--}}
                            {{--<li><a href="#"><i class="fa fa-pinterest icon"></i></a></li>--}}
                            <li><a href="#"><i class="fa fa-youtube-play icon"></i></a></li>
                            {{--<li><a href="#"><i class="fa fa-envelope icon"></i></a></li>--}}
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="footer-widget">
                        <div class="footer-widget-title">
                            <h4 class="widget-title">เส้นทางลัด</h4>
                        </div>
                        <ul class="widget-links">
                            <li><a href="#">ค้นหานักจิตวิทยา</a></li>
                            <li><a href="#">เกี่ยวกับ Relationflip</a></li>
                            <li><a href="#">จิตวิทยาน่าคิด</a></li>
                            <li><a href="#">มุมสมาชิก</a></li>
                            <li><a href="#">เงื่อนไขการใช้บริการ</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="footer-widget">
                        <div class="footer-widget-title">
                            <h4 class="widget-title">การทำงานที่เกี่ยวข้อง</h4>
                        </div>
                        <ul class="widget-links">
                            <li><a href="#">การเติบโตในบริษัท</a></li>
                            <li><a href="#">ความสัมพันธ์กับหัวหน้างาน</a></li>
                            <li><a href="#">ความสัมพันธ์กับเพื่อนร่วมงาน</a></li>
                            <li><a href="#">ค้นหาศักยภาพตนเอง</a></li>
                            <li><a href="#">พัฒนาประสิทธิภาพการทำงาน</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--Footer end-->

    {{--<!-- Start Menu Switcher -->--}}
    {{--<div class="menu-switcher">--}}
        {{--<a class="switcher-btn" id="switcher-toggle" href="#"><i class="fa fa-cog"></i></a>--}}
        {{--<h5 class="switcher-title">Reset Theme Style</h5>--}}
        {{--<h6 class="title">Chose theme color</h6>--}}
        {{--<ul class="switcher-color">--}}
            {{--<li>--}}
                {{--<a class="scr-color1" onclick="swapStyleSheet('css/color/themecolor.css')"></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a class="scr-color2" onclick="swapStyleSheet('css/color/themecolor2.css')"></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a class="scr-color3" onclick="swapStyleSheet('css/color/themecolor3.css')"></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a class="scr-color4" onclick="swapStyleSheet('css/color/themecolor4.css')"></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a class="scr-color5" onclick="swapStyleSheet('css/color/themecolor5.css')"></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a class="scr-color6" onclick="swapStyleSheet('css/color/themecolor6.css')"></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a class="scr-color7" onclick="swapStyleSheet('css/color/themecolor7.css')"></a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a class="scr-color8" onclick="swapStyleSheet('css/color/themecolor8.css')"></a>--}}
            {{--</li>--}}
        {{--</ul>--}}
        {{--<h6 class="title">Chose layout wide</h6>--}}
        {{--<ul class="switcher-laout-boxed-wide">--}}
            {{--<li>--}}
                {{--<a class="btn-widelayout" href="#btn-widelayout">Wide</a>--}}
            {{--</li>--}}
            {{--<li>--}}
                {{--<a class="btn-boxedlayout" href="#btn-boxedlayout">Boxed</a>--}}
            {{--</li>--}}
        {{--</ul>--}}
        {{--<h6 class="title">Chose Background Image <span>(Boxed Wide)</span></h6>--}}
        {{--<ul class="switcher-layout-bgimg">--}}
            {{--<li><a class="switcher-bgi-pattern">rs</a></li>--}}
            {{--<li><a><img class="switcher-bgi-pattern" src="images/resource/w01.jpg"></a></li>--}}
            {{--<li><a><img class="switcher-bgi-pattern" src="images/resource/w02.jpg"></a></li>--}}
            {{--<li><a><img class="switcher-bgi-pattern" src="images/resource/w03.jpg"></a></li>--}}
            {{--<li><a><img class="switcher-bgi-pattern" src="images/resource/w04.jpg"></a></li>--}}
            {{--<li><a><img class="switcher-bgi-pattern" src="images/resource/w05.jpg"></a></li>--}}

            {{--<li><a><img class="switcher-bgi-solid" src="images/resource/1.jpg"></a></li>--}}
            {{--<li><a><img class="switcher-bgi-solid" src="images/resource/2.jpg"></a></li>--}}
            {{--<li><a><img class="switcher-bgi-solid" src="images/resource/3.jpg"></a></li>--}}
            {{--<li><a><img class="switcher-bgi-solid" src="images/resource/4.jpg"></a></li>--}}
            {{--<li><a><img class="switcher-bgi-solid" src="images/resource/5.jpg"></a></li>--}}
            {{--<li><a><img class="switcher-bgi-solid" src="images/resource/6.jpg"></a></li>--}}
        {{--</ul>--}}
    {{--</div>--}}

<!--Scroll to top-->
    <div class="scroll-to-top"><span class="fa fa-arrow-up"></span></div>

</div>
<!--wrapper end-->

<!--Jquery Script-->
<script src="js/jquery-2.1.4.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/menuzord.js"></script>
<script src="js/jPushMenu.js"></script>
<script src="js/revolution.min.js"></script>
<script src="js/owl.js"></script>
<!-- validate -->
<script src="js/validate.js"></script>
<!-- jQuery ui js -->
<script src="js/jquery-ui-1.11.4/jquery-ui.js"></script>
<!-- appear js -->
<script src="js/jquery.appear.js"></script>
<!-- isotope -->
<script src="js/isotope.pkgd.min.js"></script>
<!-- count to -->
<script src="js/jquery.countTo.js"></script>
<!-- fancybox -->
<script src="js/jquery.fancybox.pack.js"></script>
<!-- easing -->
<script src="js/jquery.easing.min.js"></script>
<script src="js/wow.js"></script>
<script src="js/rev-custom.js"></script>
<script src="js/customcollection.js"></script>
<script src="js/custom.js"></script>

</body>
</html>