<!doctype html>
<html lang="{{ config('app.locale') }}">
<head>
    <meta charset="utf-8">
    <title>Welcome to @yield('page_title')</title>

    {{-- css --}}
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap-theme.css">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">

    {{--javascript--}}
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery.js"></script>

    {{--custom javascript--}}
    @yield('script')

</head>

<body>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            @yield('content')
            <button class="btn btn-primary"><i class="fa fa-search"></i>&nbsp;Test</button>
        </div>
    </div>
</div>
</body>
</html>