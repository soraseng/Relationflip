/**
 * Created by Champ on 8/6/2560.
 */
$(function () {
    alert('welcome from js');
});