<?php

namespace App\Http\Controllers;

use App\Test1;
use App\User;

class TestController extends Controller
{
    public function index()
    {
        $test1 = Test1::get();
        return view('home.GetData',compact('test1'));
    }

    public function show($id)
    {
        $test1 = Test1::find($id);
        if(empty($test1))
            abort(404);
        return view('home.test',compact('test1'));
    }

}
