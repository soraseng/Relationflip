<?php

namespace App\Http\Controllers;

class WelcomeController extends Controller
{
	public function index()
	{
		return view('home.welcome');
	}

	public function test()
    {
        $title = 'PHP with Laravel';
        $content ='Web Framework for php development';

        return view('home.test',['title' => $title,'content' => $content ]);
    }

	public function hello()
	{
		return 'Hello world';
	}
	public function page($id=null)
	{
		return 'welcome to page ' .$id;
	}
	
	public function getPage()
	{
		return 'Welcome To Page';	
	}
}
