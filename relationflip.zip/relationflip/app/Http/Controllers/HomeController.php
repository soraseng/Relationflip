<?php
/**
 * Created by PhpStorm.
 * User: Champ
 * Date: 10/6/2560
 * Time: 16:03
 */

namespace App\Http\Controllers;


class HomeController extends Controller
{
    public function index()
    {
        return view('home.index');
    }
    public function about()
    {
        return view('home.about');
    }
}